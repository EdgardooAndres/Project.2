package p2MainClasses;

import java.io.RandomAccessFile;

/**
 * This initiates the execution of the application that allows 
 * data analysis on the data extracted from a given file.
 * @author Edgardo Muniz
 *
 */
public class TableAnalyzer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RandomAccessFile file;
		

	}
}
